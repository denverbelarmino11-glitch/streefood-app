package com.denver.model;
import java.util.List;

public class Order {
    int id;
    String customerId;
    List<OrderItems> items;
}
