package com.denver.entity;

import lombok.Data;

import javax.persistence.*;
import java.util.Date;

@Data
@Entity
@Table(name = "OrderItem_data")
public class    OrderItemData {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    int id;
    int orderId;
    int customerId;
    String customerName;
    int productId;
    String productName;
    String imageFile;
    double quantity;
    String uom;
    double price;
    String status;
    Date dateCreated;
    Date modifiedDate;
}
