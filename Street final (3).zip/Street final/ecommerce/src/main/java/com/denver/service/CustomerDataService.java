package com.denver.service;

import com.denver.entity.CustomerData;

import java.util.List;

public interface CustomerDataService {
    List<CustomerData> getAllCustomers(); // Retrieve all customers
    CustomerData getCustomerById(int id); // Retrieve a specific customer by ID
    CustomerData saveCustomer(CustomerData customerData); // Save a new customer
    void deleteCustomer(int id); // Delete a customer by ID
    CustomerData updateCustomer(int id, CustomerData customerData); // Update an existing customer
}
