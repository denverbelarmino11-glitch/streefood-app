package com.denver.repostory;

import com.denver.entity.MenuData;
import org.springframework.data.repository.CrudRepository;

public interface MenuDataRepository extends CrudRepository<MenuData,Integer> {
}