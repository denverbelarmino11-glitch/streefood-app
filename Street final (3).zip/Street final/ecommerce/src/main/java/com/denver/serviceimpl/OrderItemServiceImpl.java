package com.denver.serviceimpl;

import com.denver.entity.OrderItemData;
import com.denver.repository.OrderItemDataRepository;
import com.denver.service.OrderItemService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.*;

@Slf4j
@Service
public class OrderItemServiceImpl implements OrderItemService {

    @Autowired
    private OrderItemDataRepository orderItemRepository;

    @Override
    public List<OrderItemData> getAllOrderItems() {
        List<OrderItemData> orderItems = new ArrayList<>();
        orderItemRepository.findAll().forEach(orderItems::add);
        return orderItems;
    }

    @Override
    public OrderItemData getOrderItemById(int id) {
        log.info("Fetching OrderItem with id: " + id);
        Optional<OrderItemData> optionalOrderItem = orderItemRepository.findById(id);
        if (optionalOrderItem.isPresent()) {
            return optionalOrderItem.get();
        } else {
            log.error("OrderItem with id " + id + " not found.");
            return null;
        }
    }

    @Override
    public OrderItemData createOrderItem(OrderItemData orderItemData) {
        log.info("Creating OrderItem: " + orderItemData);
        return orderItemRepository.save(orderItemData);
    }

    @Override
    public OrderItemData updateOrderItem(int id, OrderItemData updatedOrderItem) {
        log.info("Updating OrderItem with id: " + id);
        Optional<OrderItemData> optionalOrderItem = orderItemRepository.findById(id);
        if (optionalOrderItem.isPresent()) {
            OrderItemData existingOrderItem = optionalOrderItem.get();

            // Update fields
            existingOrderItem.setOrderId(updatedOrderItem.getOrderId());
            existingOrderItem.setCustomerId(updatedOrderItem.getCustomerId());
            existingOrderItem.setCustomerName(updatedOrderItem.getCustomerName());
            existingOrderItem.setProductId(updatedOrderItem.getProductId());
            existingOrderItem.setProductName(updatedOrderItem.getProductName());
            existingOrderItem.setImageFile(updatedOrderItem.getImageFile());
            existingOrderItem.setQuantity(updatedOrderItem.getQuantity());
            existingOrderItem.setUom(updatedOrderItem.getUom());
            existingOrderItem.setPrice(updatedOrderItem.getPrice());
            existingOrderItem.setStatus(updatedOrderItem.getStatus());
            existingOrderItem.setModifiedDate(new Date());

            return orderItemRepository.save(existingOrderItem);
        } else {
            log.error("OrderItem with id " + id + " not found.");
            return null;
        }
    }

    @Override
    public void deleteOrderItem(int id) {
        log.info("Deleting OrderItem with id: " + id);
        Optional<OrderItemData> optionalOrderItem = orderItemRepository.findById(id);
        if (optionalOrderItem.isPresent()) {
            orderItemRepository.delete(optionalOrderItem.get());
            log.info("Successfully deleted OrderItem with id: " + id);
        } else {
            log.error("OrderItem with id " + id + " not found.");
        }
    }
}
