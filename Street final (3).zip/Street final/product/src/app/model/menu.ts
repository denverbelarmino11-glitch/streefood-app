export class Menu {
    id: number =0;
    name: string = ''
    description: string = ''
    routerPath: string = ''
    categoryName: string = ''
}

