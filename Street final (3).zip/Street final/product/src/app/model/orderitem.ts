export class OrderItem {
    orderId: number;              // Unique identifier for the order
    id?: number;                  // Make id optional
    customerId: number;           // Unique identifier for the customer
    customerName: string;         // Name of the customer
    productId: number;            // Unique identifier for the product
    productName: string;          // Name of the product
    imageFile: string;            // File path or URL for the product image
    quantity: number;             // Quantity of the product ordered
    uom: string;                  // Unit of measure (e.g., piece, kg)
    price: number;                // Price of the product
    status: string;               // Current status of the order item (e.g., pending, shipped)
    dateCreated: Date;            // Date when the order item was created
    modifiedDate: Date;           // Date when the order item was last modified

    constructor(
        orderId: number,
        id: number | undefined,    // Allow id to be undefined
        customerId: number,
        customerName: string,
        productId: number,
        productName: string,
        imageFile: string,
        quantity: number,
        uom: string,
        price: number,
        status: string,
        dateCreated: Date,
        modifiedDate: Date
    ) {
        this.orderId = orderId;
        this.id = id;                 // This can now be undefined
        this.customerId = customerId;
        this.customerName = customerName;
        this.productId = productId;
        this.productName = productName;
        this.imageFile = imageFile;
        this.quantity = quantity;
        this.uom = uom;
        this.price = price;
        this.status = status;
        this.dateCreated = dateCreated;
        this.modifiedDate = modifiedDate;
    }
}
