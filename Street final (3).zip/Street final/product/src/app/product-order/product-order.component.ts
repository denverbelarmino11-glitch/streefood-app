import { Component, OnInit } from '@angular/core';
import { CartService } from '../service/cart.service';
import { RegistrationService } from '../service/registration.service';
import { OrderItem } from '../model/orderitem';
import { Customer } from '../model/customer';

@Component({
  selector: 'app-product-order',
  templateUrl: './product-order.component.html',
  styleUrls: ['./product-order.component.css']
})
export class ProductOrderComponent implements OnInit {
  public purchasedItems: OrderItem[] = []; // Track purchased items
  public showModal: boolean = false; // Control the modal visibility
  public receipt: string = ''; // To hold the generated receipt content
  public loggedInUser: Customer | null = null; // To hold logged-in customer information
  private salesTaxRate: number = 0.1; // Assuming a sales tax rate of 10%

  constructor(private cartService: CartService, private registrationService: RegistrationService) {}

  ngOnInit(): void {
    // Fetch logged-in customer info
    this.getLoggedInUser();
  }

  // Fetch logged-in customer information
  getLoggedInUser(): void {
    this.registrationService.getLoggedInUser().subscribe(
      (user: Customer | null) => {
        this.loggedInUser = user; // Store the logged-in user information
        this.loadCreatedItems(); // Load items after setting logged-in user
      },
      error => {
        console.error('Error fetching logged-in user:', error);
      }
    );
  }

  // Load created items for the logged-in user
  loadCreatedItems(): void {
    if (this.loggedInUser) {
      this.cartService.getCreatedOrderItems().subscribe(
        items => {
          // Filter items to only include those with 'Created' status
          this.purchasedItems = items.filter(item => 
            item.customerId === this.loggedInUser!.id && item.status === 'Created'
          );
        },
        error => {
          console.error('Error fetching created items:', error);
        }
      );
    }
  }

  // Generate receipt and update status to 'Purchased'
  generateReceipt(): void {
    if (!this.purchasedItems.length || !this.loggedInUser) {
      console.log('No items to generate receipt for or user is not logged in.');
      return;
    }

    const customerFullName = this.getCustomerFullName(this.loggedInUser);
    this.receipt = `Receipt for ${customerFullName} (Username: ${this.loggedInUser.username})\n\n`;
    
    // Calculate subtotal
    const subtotal = this.calculateSubtotal();

    // Calculate financials
    const { salesTax, totalCost } = this.calculateFinancials(subtotal);

    // Build receipt content
    this.buildReceiptContent(subtotal, salesTax, totalCost);

    // Update item statuses
    this.updateItemsStatus('Purchased');

    // Open the receipt modal
    this.showModal = true; 
  }

  private getCustomerFullName(user: Customer): string {
    return `${user.firstname} ${user.middlename ? user.middlename + ' ' : ''}${user.lastname}`;
  }

  private calculateSubtotal(): number {
    return this.purchasedItems.reduce((total, item) => total + item.price * item.quantity, 0);
  }

  private calculateFinancials(subtotal: number): { salesTax: number, totalCost: number } {
    const salesTax = subtotal * this.salesTaxRate;
    const totalCost = subtotal + salesTax;
    return { salesTax, totalCost };
  }

  private buildReceiptContent(subtotal: number, salesTax: number, totalCost: number): void {
    // Reset the receipt to avoid appending to previous content
    this.receipt += 'Items:\n';
    this.purchasedItems.forEach(item => {
      this.receipt += `${item.productName} - Quantity: ${item.quantity} - Price: $${item.price.toFixed(2)}\n`;
    });
    this.receipt += `\nSubtotal: $${subtotal.toFixed(2)}\n`;
    this.receipt += `Sales Tax: $${salesTax.toFixed(2)}\n`;
    this.receipt += `Total Cost: $${totalCost.toFixed(2)}\n`;
  }

  private updateItemsStatus(status: string): void {
    this.purchasedItems.forEach(item => {
      if (item.status === 'Created') { // Only update if status is 'Created'
        item.status = status; // Setting status to 'Purchased'
        this.cartService.updateCartItem(item).subscribe(
          response => {
            console.log(`Item ${item.productName} updated to '${status}'.`);
          },
          error => {
            console.error(`Error updating item ${item.productName}:`, error);
          }
        );
      }
    });
  }

  // Close the receipt modal
  closeReceipt(): void {
    this.showModal = false; // Hide the modal
  }

  cancelOrder(orderItem: OrderItem): void {
    if (orderItem.status === 'Created') {
      orderItem.status = 'Pending'; // Change status to 'Pending'
      this.cartService.updateCartItem(orderItem).subscribe(
        response => {
          console.log(`Order item ${orderItem.productName} cancelled and status updated to 'Pending'.`);
          this.loadCreatedItems(); // Reload items to reflect the change
        },
        error => {
          console.error(`Error cancelling order item ${orderItem.productName}:`, error);
        }
      );
    }
  }

  cancelAllOrders(): void {
    this.purchasedItems.forEach(item => {
      if (item.status === 'Created') {
        item.status = 'Pending'; // Change status to 'Pending'
        this.cartService.updateCartItem(item).subscribe(
          response => {
            console.log(`Order item ${item.productName} cancelled and status updated to 'Pending'.`);
          },
          error => {
            console.error(`Error cancelling order item ${item.productName}:`, error);
          }
        );
      }
    });
    // Reload items to reflect the change
    this.loadCreatedItems();
  }
}
