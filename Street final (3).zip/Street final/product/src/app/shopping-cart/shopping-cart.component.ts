import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { CartService } from '../service/cart.service';
import { OrderItem } from '../model/orderitem';
import { forkJoin } from 'rxjs';
import { RegistrationService } from '../service/registration.service'; // Import RegistrationService

@Component({
  selector: 'app-shopping-cart',
  templateUrl: './shopping-cart.component.html',
  styleUrls: ['./shopping-cart.component.css']
})
export class ShoppingCartComponent implements OnInit {
  public orderItems: OrderItem[] = [];
  public notificationMessage: string = ''; // Notification message for user feedback

  constructor(private cartService: CartService, private router: Router, private registrationService: RegistrationService) { } // Inject RegistrationService

  ngOnInit(): void {
    this.loadCartItems();
  }

  loadCartItems(): void {
    this.cartService.getCartItems().subscribe(
      (data: OrderItem[]) => {
        this.orderItems = data;
      },
      error => {
        console.error('Error fetching cart items:', error);
      }
    );
  }

  get pendingItems(): OrderItem[] {
    return this.orderItems.filter(item => item.status === 'Pending');
  }

  removeItem(orderItemId: number): void {
    const itemToRemove = this.orderItems.find(item => item.id === orderItemId);
    if (itemToRemove) {
        if (itemToRemove.quantity > 1) {
            this.decrementQuantity(itemToRemove);
        } else {
            this.cartService.removeOrderItem(orderItemId).subscribe(
                () => {
                    this.notificationMessage = `Item ${itemToRemove.productName} removed from cart successfully`;
                    console.log(this.notificationMessage);
                    this.orderItems = this.orderItems.filter(item => item.id !== orderItemId);
                },
                error => {
                    console.error(`Error removing item ${itemToRemove.productName} from cart:`, error);
                }
            );
        }
    } else {
        console.error('Item not found to remove:', orderItemId);
    }
}

decrementQuantity(item: OrderItem): void {
  if (item.quantity > 1) {
      item.quantity--;
      this.cartService.updateOrderItem(item).subscribe(
          () => {
              this.notificationMessage = `Quantity of item ${item.productName} decremented`;
              console.log(this.notificationMessage);
          },
          error => {
              console.error(`Error updating item quantity for ${item.productName}:`, error);
          }
      );
  } else {
      // Ensure item.id is defined before calling removeItem
      if (item.id !== undefined) {
          this.removeItem(item.id);
      } else {
          console.error('Item ID is undefined, cannot remove item:', item);
      }
  }
}


  calculateTotal(): number {
    return this.pendingItems.reduce((total, item) => total + (item.price * item.quantity), 0);
  }

  checkout(): void {
    // Check if a customer is logged in
    this.registrationService.getLoggedInUser().subscribe(
      loggedInCustomer => {
        if (!loggedInCustomer) {
          // Display an alert to notify the user that they need to log in
          this.notificationMessage = 'You must be logged in to checkout.';
          console.warn(this.notificationMessage);
          window.alert(this.notificationMessage); // Display alert
          return; // Stop the checkout process
        }

        // Proceed with checkout if the user is logged in
        const statusUpdateObservables = this.pendingItems.map(item => {
          item.status = 'Created'; // Update status
          item.customerId = loggedInCustomer.id; // Replace with logged-in customer ID
          item.customerName = loggedInCustomer.username; // Replace with logged-in customer name
          return this.cartService.updateOrderItem(item); // Create observable for the update
        });

        // Wait for all status updates to complete
        forkJoin(statusUpdateObservables).subscribe(
          () => {
            // Clear the displayed items
            this.orderItems = this.orderItems.filter(item => item.status !== 'Pending'); // Keep only non-pending items

            // Clear the cart on the server
            this.cartService.clearCart().subscribe(
              () => {
                console.log('Cart cleared successfully');
                this.notificationMessage = 'Checkout completed successfully!'; // Notify user
              },
              error => {
                console.error('Error clearing cart:', error);
              }
            );
          },
          error => {
            console.error('Error updating item statuses:', error);
          }
        );
      },
      error => {
        console.error('Error checking logged in status:', error);
      }
    );
  }
}
