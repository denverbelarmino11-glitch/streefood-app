package com.denver.repository;

import com.denver.entity.OrderItemData;
import org.springframework.data.repository.CrudRepository;

public interface OrderItemDataRepository extends CrudRepository<OrderItemData,Integer> {
}
