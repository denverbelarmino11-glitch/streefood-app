package com.denver.model;

public class Category {
    int id;
    String name;
    String description;
}
