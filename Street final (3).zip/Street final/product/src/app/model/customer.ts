// src/app/model/customer.ts

export enum Gender {
  Male = 'male',
  Female = 'female',
  Other = 'other'
}

export class Customer {
  id: number;
  username: string;
  firstname: string;
  middlename: string;
  lastname: string;
  email: string;
  dateOfBirth: Date;
  gender: Gender;       
  password: string;
  profilePicture: string;
  status: string; // Added status property

  constructor(
    id: number,
    username: string,
    firstname: string,
    middlename: string,
    lastname: string,
    email: string,
    dateOfBirth: Date,
    gender: Gender,
    password: string,
    profilePicture: string,
    status: string // Added status parameter
  ) {
    this.id = id;
    this.username = username;
    this.firstname = firstname;
    this.middlename = middlename;
    this.lastname = lastname;
    this.email = email;
    this.dateOfBirth = dateOfBirth;
    this.gender = gender;
    this.password = password;
    this.profilePicture = profilePicture; 
    this.status = status; // Initialize status
  }
}
