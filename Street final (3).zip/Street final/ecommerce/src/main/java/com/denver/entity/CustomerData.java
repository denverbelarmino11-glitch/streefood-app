package com.denver.entity;

import lombok.Data;

import javax.persistence.*;
import java.util.Date;

@Data
@Entity
@Table(name = "customer_data")
public class    CustomerData {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    int id;
    String username;
    String firstname;
    String middlename;
    String lastname;
    String password;
    String email;
    Date DateOfBirth;
    String Gender;
    String profilePicture;
    String status;
}


