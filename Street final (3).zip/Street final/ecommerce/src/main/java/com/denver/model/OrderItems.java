
package com.denver.model;
import lombok.Data;

import java.util.*;

@Data
public class OrderItems {
    int id;
    int orderId;
    int customerId;
    String customerName;
    int productId;
    String productName;
    String imageFile;
    double quantity;
    String uom;
    double price;
    String status;
    Date dateCreated;
    Date modifiedDate;
}
