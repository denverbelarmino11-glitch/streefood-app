package com.denver.service;

import com.denver.entity.OrderItemData;

import java.util.List;

public interface OrderItemService {
    List<OrderItemData> getAllOrderItems();
    OrderItemData getOrderItemById(int id);
    OrderItemData createOrderItem(OrderItemData orderItemData);
    OrderItemData updateOrderItem(int id, OrderItemData orderItemData);
    void deleteOrderItem(int id);
}
