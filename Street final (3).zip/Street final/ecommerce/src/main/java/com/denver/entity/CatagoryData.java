package com.denver.entity;

public class CatagoryData {
}
