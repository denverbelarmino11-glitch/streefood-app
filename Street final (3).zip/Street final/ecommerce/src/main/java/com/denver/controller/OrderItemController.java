package com.denver.controller;

import com.denver.entity.OrderItemData;
import com.denver.service.OrderItemService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@CrossOrigin(origins = "http://localhost:4200")
@Slf4j
@RequestMapping("/api/orderitem")
public class OrderItemController {

    @Autowired
    private OrderItemService orderItemService;

    // Get all OrderItems
    @GetMapping
    public ResponseEntity<List<OrderItemData>> getAllOrderItems() {
        try {
            List<OrderItemData> orderItems = orderItemService.getAllOrderItems();
            log.warn("Order Items Count: {}", orderItems.size());
            return ResponseEntity.ok(orderItems);
        } catch (Exception ex) {
            log.error("Failed to retrieve order items: {}", ex.getMessage(), ex);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(null);
        }
    }

    // Get OrderItem by ID
    @GetMapping("/{id}")
    public ResponseEntity<OrderItemData> getOrderItemById(@PathVariable final Integer id) {
        log.info("Fetching OrderItem with ID: {}", id);
        try {
            OrderItemData orderItem = orderItemService.getOrderItemById(id);
            if (orderItem != null) {
                return ResponseEntity.ok(orderItem);
            } else {
                return ResponseEntity.status(HttpStatus.NOT_FOUND).body(null);
            }
        } catch (Exception ex) {
            log.error("Failed to retrieve order item with id: {}", ex.getMessage(), ex);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(null);
        }
    }

    // Update an OrderItem
    @PutMapping("/{id}")
    public ResponseEntity<OrderItemData> updateOrderItem(@PathVariable final Integer id, @RequestBody OrderItemData orderItemData) {
        log.info("Updating OrderItem with ID: {} and data: {}", id, orderItemData);
        try {
            OrderItemData updatedOrderItem = orderItemService.updateOrderItem(id, orderItemData);
            return ResponseEntity.ok(updatedOrderItem);
        } catch (Exception ex) {
            log.error("Failed to update order item: {}", ex.getMessage(), ex);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(null);
        }
    }

    // Create a new OrderItem
    @PostMapping
    public ResponseEntity<OrderItemData> createOrderItem(@RequestBody OrderItemData orderItemData) {
        log.info("Creating new OrderItem: {}", orderItemData);
        try {
            OrderItemData createdOrderItem = orderItemService.createOrderItem(orderItemData);
            return ResponseEntity.status(HttpStatus.CREATED).body(createdOrderItem);
        } catch (Exception ex) {
            log.error("Failed to create order item: {}", ex.getMessage(), ex);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(null);
        }
    }

    // Delete an OrderItem
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteOrderItem(@PathVariable final Integer id) {
        log.info("Deleting OrderItem with ID: {}", id);
        try {
            orderItemService.deleteOrderItem(id);
            return ResponseEntity.noContent().build();
        } catch (Exception ex) {
            log.error("Failed to delete order item: {}", ex.getMessage(), ex);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(null);
        }
    }
}

