import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { RegistrationService } from '../service/registration.service';
import { Customer } from '../model/customer'; // Adjust this import based on your structure

@Component({
  selector: 'app-customer',
  templateUrl: './customer.component.html',
  styleUrls: ['./customer.component.css']
})
export class CustomerComponent implements OnInit {
  customerForm: FormGroup;
  profilePictures: string[] = [
    'assets/Profile Pictures/cat.jpg',
    'assets/Profile Pictures/duck.jpg',
    'assets/Profile Pictures/fox.jpg',
    'assets/Profile Pictures/monke.jpg',
    'assets/Profile Pictures/rat.jpg'
  ];
  profileImage: string | null = null; // Store the selected profile image
  status: string | null = null; // New property for status message

  // Define the genders property
  genders: string[] = ['Male', 'Female', 'Other']; // Add more options as needed

  constructor(private fb: FormBuilder, private registrationService: RegistrationService) {
    this.customerForm = this.fb.group({
      username: ['', Validators.required],
      firstname: ['', Validators.required],
      middlename: [''],
      lastname: ['', Validators.required],
      email: ['', [Validators.required, Validators.email]],
      dateOfBirth: ['', Validators.required],
      gender: ['', Validators.required],
      password: ['', Validators.required],
    });
  }

  ngOnInit(): void {}

  // Method to set selected profile picture
  selectProfilePicture(image: string) {
    this.profileImage = image; // Set the selected image
  }

  // Handle form submission
  onSubmit() {
    if (this.customerForm.valid) {
      const username = this.customerForm.value.username;

      // Check if the username already exists
      this.registrationService.checkUsernameExists(username).subscribe(exists => {
        if (exists) {
          alert('Username is already taken. Please choose a different one.'); // Alert for username conflict
          return; // Stop further processing
        }

        const customerData: Customer = {
          ...this.customerForm.value,
          id: null, // Adjust as needed if your backend generates an ID
          dateOfBirth: new Date(this.customerForm.value.dateOfBirth), // Convert to Date object
        };

        // Pass customerData and profileImage to the registration service
        this.registrationService.registerCustomer(customerData, this.profileImage).subscribe(response => {
          // Set status to 'Created' if registration is successful
          this.status = 'Created'; // Set the status message
          alert('Customer registered successfully!');
          this.customerForm.reset(); // Reset the form after submission
          this.profileImage = null; // Reset the profile image preview
        }, error => {
          console.error('Error registering customer:', error);
          this.status = null; // Clear status on error
          alert('There was an error registering the customer. Please try again.');
        });
      });
    } else {
      alert('Please fill in properly all required fields!');
    }
  }
}
