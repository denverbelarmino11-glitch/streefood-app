package com.denver.entity;

public class AppDetailData {
}
