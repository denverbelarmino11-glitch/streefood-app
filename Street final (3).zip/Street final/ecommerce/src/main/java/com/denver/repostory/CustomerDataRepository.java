package com.denver.repostory;

import com.denver.entity.CustomerData;
import org.springframework.data.repository.CrudRepository;

public interface CustomerDataRepository extends CrudRepository<CustomerData,Integer> {
}