import { Component } from '@angular/core';
import { RegistrationService } from '../service/registration.service';
import { Customer } from '../model/customer'; // Adjust the import based on your structure

@Component({
  selector: 'app-account',
  templateUrl: './account.component.html',
  styleUrls: ['./account.component.css']
})
export class AccountComponent {
  username: string = '';
  password: string = '';
  status: string | null = null; // Store the login status message

  constructor(private registrationService: RegistrationService) {}

  onLogin() {
    if (this.username && this.password) {
      this.registrationService.loginUser(this.username, this.password).subscribe(
        (response: Customer | null) => {
          if (response) {
            // Successfully logged in
            this.status = 'Logged in'; // Update status
            console.log('Login successful:', response);
  
            // Update the customer status to 'logged in'
            this.registrationService.updateCustomerStatus(response.id, 'logged in').subscribe(
              () => {
                console.log('Customer status updated:', response);
                window.alert('Account successfully logged in.');
              },
              (error) => {
                console.error('Failed to update status:', error);
                this.status = 'Failed to update status. Please try again.';
              }
            );
          } else {
            // Handle denied login
            this.status = 'Another account is already logged in. Please log out first.';
            window.alert(this.status);
          }
        },
        (error) => {
          console.error('Login failed:', error);
          this.status = 'An error occurred. Please try again later.';
          window.alert(this.status);
        }
      );
    } else {
      this.status = 'Please enter both username and password.';
      window.alert(this.status);
    }
  }
}  