package com.denver.serviceimpl;
import com.denver.entity.CustomerData;
import com.denver.repostory.CustomerDataRepository;
import com.denver.service.CustomerDataService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.*;

@Slf4j
@Service
public class CustomerDataServiceImpl implements CustomerDataService {

    @Autowired
    private CustomerDataRepository customerDataRepository;

    @Override
    public List<CustomerData> getAllCustomers() {
        List<CustomerData> customers = new ArrayList<>();
        customerDataRepository.findAll().forEach(customers::add);
        return customers;
    }

    @Override
    public CustomerData getCustomerById(int id) {
        log.info("Fetching Customer with id: {}", id);
        return customerDataRepository.findById(id)
                .orElseGet(() -> {
                    log.error("Customer with id {} not found.", id);
                    return null; // Return null if not found
                });
    }

    @Override
    public CustomerData saveCustomer(CustomerData customerData) {
        log.info("Saving Customer: {}", customerData);
        customerData.setStatus("Created"); // Set the status to 'Created'
        return customerDataRepository.save(customerData);
    }

    @Override
    public void deleteCustomer(int id) {
        log.info("Deleting Customer with id: {}", id);
        customerDataRepository.findById(id).ifPresentOrElse(
                customer -> {
                    customerDataRepository.delete(customer);
                    log.info("Successfully deleted Customer with id: {}", id);
                },
                () -> log.error("Customer with id {} not found.", id)
        );
    }

    @Override
    public CustomerData updateCustomer(int id, CustomerData customerData) {
        log.info("Updating Customer with id: {}", id);
        return customerDataRepository.findById(id).map(existingCustomer -> {
            // Update the fields of existingCustomer with customerData
            existingCustomer.setUsername(customerData.getUsername());
            existingCustomer.setFirstname(customerData.getFirstname());
            existingCustomer.setMiddlename(customerData.getMiddlename());
            existingCustomer.setLastname(customerData.getLastname());
            existingCustomer.setEmail(customerData.getEmail());
            existingCustomer.setDateOfBirth(customerData.getDateOfBirth());
            existingCustomer.setGender(customerData.getGender());
            existingCustomer.setPassword(customerData.getPassword());
            existingCustomer.setStatus(customerData.getStatus()); // Retain the existing status

            log.info("Successfully updated Customer with id: {}", id);
            return customerDataRepository.save(existingCustomer);
        }).orElseGet(() -> {
            log.error("Customer with id {} not found for update.", id);
            return null; // Return null if customer not found
        });
    }
}
