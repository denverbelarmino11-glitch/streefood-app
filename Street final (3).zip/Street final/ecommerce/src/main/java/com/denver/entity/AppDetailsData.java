package com.denver.entity;

public class AppDetailsData
{

}
