package com.denver.model;

public class AppDetail {
    int id;
    String name;
    String description;
}
