package com.denver.controller;

import com.denver.entity.CustomerData;
import com.denver.service.CustomerDataService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@CrossOrigin(origins = "http://localhost:4200") // Allow cross-origin requests from Angular app
@Slf4j
@RequestMapping("/api/customers") // Base URL for customer-related endpoints
public class CustomerController {

    @Autowired
    private CustomerDataService customerDataService;

    // Get all customers
    @GetMapping
    public ResponseEntity<List<CustomerData>> getAllCustomers() {
        List<CustomerData> customers = customerDataService.getAllCustomers();
        return new ResponseEntity<>(customers, HttpStatus.OK);
    }

    // Get a specific customer by ID
    @GetMapping("/{id}")
    public ResponseEntity<CustomerData> getCustomerById(@PathVariable int id) {
        CustomerData customer = customerDataService.getCustomerById(id);
        if (customer != null) {
            return new ResponseEntity<>(customer, HttpStatus.OK);
        } else {
            log.error("Customer with id {} not found.", id);
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    // Create a new customer
    @PostMapping
    public ResponseEntity<CustomerData> createCustomer(@RequestBody CustomerData customerData) {
        CustomerData createdCustomer = customerDataService.saveCustomer(customerData);
        return new ResponseEntity<>(createdCustomer, HttpStatus.CREATED);
    }

    // Update an existing customer
    @PutMapping("/{id}")
    public ResponseEntity<CustomerData> updateCustomer(@PathVariable int id, @RequestBody CustomerData customerData) {
        customerData.setId(id); // Set the ID to ensure the correct customer is updated
        CustomerData updatedCustomer = customerDataService.updateCustomer(id, customerData);
        if (updatedCustomer != null) {
            return new ResponseEntity<>(updatedCustomer, HttpStatus.OK);
        } else {
            log.error("Customer with id {} not found for update.", id);
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    // Delete a customer
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteCustomer(@PathVariable int id) {
        customerDataService.deleteCustomer(id);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }
}
