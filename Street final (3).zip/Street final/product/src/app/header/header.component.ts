import { Component, OnInit } from '@angular/core';
import { MenuService } from '../service/menu.service';
import { Router } from '@angular/router';
import { RegistrationService } from '../service/registration.service';
import { CartService } from '../service/cart.service';
import { Customer } from '../model/customer';
import { OrderItem } from '../model/orderitem';
import { Menu } from '../model/menu'; // Ensure this import is correct

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {
  public menus: Menu[] = [];
  public profileImage: string = 'assets/user-icon.png'; // Default profile image
  public loggedInUser: Customer | null = null; // Store logged in user data
  public showModal: boolean = false; // Flag to show modal
  public purchasedItems: OrderItem[] = []; // Store purchased items

  constructor(
    private menuService: MenuService,
    private router: Router,
    private registrationService: RegistrationService,
    private cartService: CartService // Inject CartService
  ) {}

  ngOnInit(): void {
      this.menuService.getData().subscribe(data => {
      this.menus = data;
    });

    this.registrationService.getLoggedInUser().subscribe(user => {
      if (user) {
        this.loggedInUser = user; // Save logged in user data
        this.profileImage = user.profilePicture;
      }
    });
  }

  checkProduct(searchTerm: string): void {
    console.log('Searching for:', searchTerm);
  }

  navigateToLogin(): void {
    this.router.navigate(['/login']);
  }

  showUserData(): void {
    this.showModal = true; // Show the modal when circle image is clicked

    // Fetch purchased items for the logged-in user
    if (this.loggedInUser) {
      this.cartService.getPurchasedOrderItems().subscribe(
        items => {
          // Filter items to only include those with 'Purchased' status
          this.purchasedItems = items.filter(item => 
            item.customerId === this.loggedInUser?.id && item.status === 'Purchased'
          );
        },
        error => {
          console.error('Error fetching purchased items:', error);
        }
      );
    }
  }

  closeModal(): void {
    this.showModal = false; // Hide the modal
  }

  logout(): void {
    if (this.loggedInUser) {
      this.registrationService.logoutUser(this.loggedInUser).subscribe(
        response => {
          this.loggedInUser = null; // Clear user data
          this.profileImage = 'assets/anonymous.jpg'; // Reset profile image
          console.log('Logged out successfully.');
          this.router.navigate(['/login']);
        },
        error => {
          console.error('Error logging out:', error);
        }
      );
    }
  }
}
