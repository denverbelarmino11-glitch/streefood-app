import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, of, throwError } from 'rxjs';
import { catchError, map, switchMap } from 'rxjs/operators';
import { Customer } from '../model/customer';
import { OrderItem } from '../model/orderitem';

@Injectable({
  providedIn: 'root'
})
export class RegistrationService {
  private apiUrl = 'http://localhost:8080/api/customers'; // Ensure this URL is correct

  constructor(private http: HttpClient) {}

  // Method to register a new customer
  registerCustomer(customer: Customer, profilePicture: string | null): Observable<Customer> {
    const customerData = { ...customer, profilePicture }; // Combine customer data and profile picture URL
    return this.http.post<Customer>(this.apiUrl, customerData).pipe(
      catchError(this.handleError)
    );
  }

  // Method to log in a customer
  loginUser(username: string, password: string): Observable<Customer | null> {
    return this.getLoggedInUser().pipe( // Check for logged in user first
      switchMap(loggedInUser => {
        if (loggedInUser) {
          // If there is a logged-in user, deny login
          return of(null); // Return null to indicate that login is denied
        } else {
          // Proceed with checking the username and password
          return this.http.get<Customer[]>(this.apiUrl).pipe(
            map(customers => {
              // Check if any customer matches the username and password
              const customer = customers.find(
                (cust) => cust.username === username && cust.password === password
              );
              return customer || null; // Return the customer if found, else return null
            }),
            catchError(this.handleError)
          );
        }
      }),
      catchError(this.handleError)
    );
  }

  // Method to update the status of a customer
  updateCustomerStatus(customerId: number, newStatus: string): Observable<Customer> {
    return this.http.get<Customer>(`${this.apiUrl}/${customerId}`).pipe(
      map(existingCustomer => {
        const updatedCustomer = { ...existingCustomer, status: newStatus };
        return updatedCustomer;
      }),
      switchMap(updatedCustomer => this.http.put<Customer>(`${this.apiUrl}/${customerId}`, updatedCustomer)),
      catchError(this.handleError)
    );
  }

  // Method to check if a specific customer is logged in
  checkCustomerStatus(username: string): Observable<string | null> {
    return this.http.get<Customer[]>(this.apiUrl).pipe(
      map(customers => {
        const customer = customers.find(cust => cust.username === username);
        return customer ? customer.status : null; // Return the customer's status if found, else return null
      }),
      catchError(this.handleError)
    );
  }

  // Method to check if the username already exists
  checkUsernameExists(username: string): Observable<boolean> {
    return this.http.get<Customer[]>(this.apiUrl).pipe(
      map(customers => customers.some(cust => cust.username === username)),
      catchError(() => of(false)) // Return false if there’s an error
    );
  }

  getLoggedInUser(): Observable<Customer | null> {
    return this.http.get<Customer[]>(this.apiUrl).pipe(
      map(customers => {
        // Filter customers to find the one with 'logged in' status
        const loggedInCustomer = customers.find(cust => cust.status === 'logged in');
        return loggedInCustomer || null;
      }),
      catchError(this.handleError)
    );
  }

  logoutUser(customer: Customer): Observable<Customer> {
    return this.http.put<Customer>(`${this.apiUrl}/${customer.id}`, { ...customer, status: 'Created' }).pipe(
      catchError(this.handleError)
    );
  }

  // Handle errors from API calls
  private handleError(error: any): Observable<never> {
    console.error('An error occurred:', error); // Log error to console
    return throwError(error); // Rethrow the error
  }
}
