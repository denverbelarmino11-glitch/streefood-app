import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';
import { catchError, map } from 'rxjs/operators';
import { OrderItem } from '../model/orderitem';

@Injectable({
  providedIn: 'root'
})
export class CartService {
  private baseUrl = 'http://localhost:8080/api/orderitem'; // Base URL for your API

  constructor(private http: HttpClient) {}

  // Add a new order item
  addOrderItem(orderItem: OrderItem): Observable<OrderItem> {
    return this.http.post<OrderItem>(`${this.baseUrl}`, orderItem)
      .pipe(
        catchError(this.handleError)
      );
  }


  // Update an existing order item
  updateOrderItem(orderItem: OrderItem): Observable<OrderItem> {
    return this.http.put<OrderItem>(`${this.baseUrl}/${orderItem.id}`, orderItem)
      .pipe(
        catchError(this.handleError)
      );
  }

  // Remove an order item by ID
  removeOrderItem(orderItemId: number): Observable<void> {
    return this.http.delete<void>(`${this.baseUrl}/${orderItemId}`)
      .pipe(
        catchError(this.handleError)
      );
  }

  // Fetch all cart items
  getCartItems(): Observable<OrderItem[]> {
    return this.http.get<OrderItem[]>(`${this.baseUrl}`)
      .pipe(
        catchError(this.handleError)
      );
  }

  // Clear the cart (assuming your API supports this endpoint)
  clearCart(): Observable<void> {
    return this.http.delete<void>(`${this.baseUrl}/clear`)
      .pipe(
        catchError(this.handleError)
      );
  }

  // Fetch only 'Created' order items (assuming your API supports query parameters)
  getCreatedOrderItems(): Observable<OrderItem[]> {
    return this.http.get<OrderItem[]>(`${this.baseUrl}?status=Created`)
      .pipe(
        catchError(this.handleError)
      );
  }

  

  getPurchasedOrderItems(): Observable<OrderItem[]> {
    return this.http.get<OrderItem[]>(`${this.baseUrl}?status=Purchased`)
      .pipe(
        catchError(this.handleError)
      );
  }

  // Update a cart item (made consistent with the baseUrl)
  updateCartItem(item: OrderItem): Observable<any> {
    return this.http.put(`${this.baseUrl}/${item.id}`, item)
      .pipe(
        catchError(this.handleError)
      );
  }

  // In cart.service.ts
getOrderItemsByCustomerId(customerId: number): Observable<OrderItem[]> {
  return this.http.get<OrderItem[]>(`${this.baseUrl}?customerId=${customerId}`)
    .pipe(
      catchError(this.handleError)
    );
}


  // Error handling method
  private handleError(error: any): Observable<any> {
    console.error('An error occurred:', error);
    throw error;
  }
}
