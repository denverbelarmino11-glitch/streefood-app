import { Injectable } from '@angular/core';
import { BaseHttpService } from './base-http.service';
import { BehaviorSubject, Observable } from 'rxjs';
import { OrderItem } from '../model/orderitem';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class OrderitemService extends BaseHttpService{

  constructor(protected override http: HttpClient) { 
    super(http, '/api/orderitem')
  }
 }
