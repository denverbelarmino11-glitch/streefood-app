package com.denver.model;
import lombok.Data;

import java.util.*;

@Data
public class Customer {
    int id;
    String username;
    String firstname;
    String middlename;
    String lastname;
    String password;
    String email;
    Date DateOfBirth;
    String Gender;
    String profilePicture;
    String status;
}